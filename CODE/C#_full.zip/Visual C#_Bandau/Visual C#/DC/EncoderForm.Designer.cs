﻿namespace DC
{
    partial class EncoderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SerialPort = new System.IO.Ports.SerialPort(this.components);
            this.TimerPort = new System.Windows.Forms.Timer(this.components);
            this.GraphPos = new ZedGraph.ZedGraphControl();
            this.GraphVel = new ZedGraph.ZedGraphControl();
            this.gbConnect = new System.Windows.Forms.GroupBox();
            this.btDisconnect = new System.Windows.Forms.Button();
            this.btConnect = new System.Windows.Forms.Button();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.cbComName = new System.Windows.Forms.ComboBox();
            this.cbSeclectCom = new System.Windows.Forms.ComboBox();
            this.TimerGraph = new System.Windows.Forms.Timer(this.components);
            this.gbControl = new System.Windows.Forms.GroupBox();
            this.btnShowVelData = new System.Windows.Forms.Button();
            this.btnShowPosData = new System.Windows.Forms.Button();
            this.btPause = new System.Windows.Forms.Button();
            this.btExit = new System.Windows.Forms.Button();
            this.btScale = new System.Windows.Forms.Button();
            this.btStart = new System.Windows.Forms.Button();
            this.grbSetVel = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btReSet = new System.Windows.Forms.Button();
            this.btSetPoint = new System.Windows.Forms.Button();
            this.txtVelocity = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.rbtVelocity = new System.Windows.Forms.RadioButton();
            this.rbtPosition = new System.Windows.Forms.RadioButton();
            this.gbCurrent = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CalibFirst = new System.Windows.Forms.Button();
            this.CalibFail = new System.Windows.Forms.Button();
            this.CalibDone = new System.Windows.Forms.Button();
            this.txtUd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUq = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtVel = new System.Windows.Forms.TextBox();
            this.txtPos = new System.Windows.Forms.TextBox();
            this.txtKdSet = new System.Windows.Forms.TextBox();
            this.txtKiSet = new System.Windows.Forms.TextBox();
            this.txtKpSet = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bkgdWorker = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.contextMenuStripPosGraph = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnResetRamp = new System.Windows.Forms.Button();
            this.btnSetRamp = new System.Windows.Forms.Button();
            this.txtTimeRamp = new System.Windows.Forms.TextBox();
            this.txtPosRamp = new System.Windows.Forms.TextBox();
            this.gbConnect.SuspendLayout();
            this.gbControl.SuspendLayout();
            this.grbSetVel.SuspendLayout();
            this.gbCurrent.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // GraphPos
            // 
            this.GraphPos.Location = new System.Drawing.Point(15, 341);
            this.GraphPos.Margin = new System.Windows.Forms.Padding(5);
            this.GraphPos.Name = "GraphPos";
            this.GraphPos.ScrollGrace = 0D;
            this.GraphPos.ScrollMaxX = 0D;
            this.GraphPos.ScrollMaxY = 0D;
            this.GraphPos.ScrollMaxY2 = 0D;
            this.GraphPos.ScrollMinX = 0D;
            this.GraphPos.ScrollMinY = 0D;
            this.GraphPos.ScrollMinY2 = 0D;
            this.GraphPos.Size = new System.Drawing.Size(929, 268);
            this.GraphPos.TabIndex = 0;
            this.GraphPos.Load += new System.EventHandler(this.GraphPos_Load);
            // 
            // GraphVel
            // 
            this.GraphVel.Location = new System.Drawing.Point(14, 619);
            this.GraphVel.Margin = new System.Windows.Forms.Padding(5);
            this.GraphVel.Name = "GraphVel";
            this.GraphVel.ScrollGrace = 0D;
            this.GraphVel.ScrollMaxX = 0D;
            this.GraphVel.ScrollMaxY = 0D;
            this.GraphVel.ScrollMaxY2 = 0D;
            this.GraphVel.ScrollMinX = 0D;
            this.GraphVel.ScrollMinY = 0D;
            this.GraphVel.ScrollMinY2 = 0D;
            this.GraphVel.Size = new System.Drawing.Size(930, 262);
            this.GraphVel.TabIndex = 1;
            this.GraphVel.Load += new System.EventHandler(this.GraphVel_Load);
            // 
            // gbConnect
            // 
            this.gbConnect.Controls.Add(this.btDisconnect);
            this.gbConnect.Controls.Add(this.btConnect);
            this.gbConnect.Controls.Add(this.cbBaudRate);
            this.gbConnect.Controls.Add(this.cbComName);
            this.gbConnect.Controls.Add(this.cbSeclectCom);
            this.gbConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbConnect.Location = new System.Drawing.Point(943, 178);
            this.gbConnect.Margin = new System.Windows.Forms.Padding(4);
            this.gbConnect.Name = "gbConnect";
            this.gbConnect.Padding = new System.Windows.Forms.Padding(4);
            this.gbConnect.Size = new System.Drawing.Size(380, 105);
            this.gbConnect.TabIndex = 2;
            this.gbConnect.TabStop = false;
            this.gbConnect.Text = "Disconnect";
            // 
            // btDisconnect
            // 
            this.btDisconnect.Location = new System.Drawing.Point(259, 58);
            this.btDisconnect.Margin = new System.Windows.Forms.Padding(4);
            this.btDisconnect.Name = "btDisconnect";
            this.btDisconnect.Size = new System.Drawing.Size(95, 39);
            this.btDisconnect.TabIndex = 1;
            this.btDisconnect.Text = "Disconnect";
            this.btDisconnect.UseVisualStyleBackColor = true;
            this.btDisconnect.Click += new System.EventHandler(this.btDisconnect_Click);
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(173, 58);
            this.btConnect.Margin = new System.Windows.Forms.Padding(4);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(84, 39);
            this.btConnect.TabIndex = 1;
            this.btConnect.Text = "Connect";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.Location = new System.Drawing.Point(12, 63);
            this.cbBaudRate.Margin = new System.Windows.Forms.Padding(4);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(76, 25);
            this.cbBaudRate.TabIndex = 0;
            // 
            // cbComName
            // 
            this.cbComName.FormattingEnabled = true;
            this.cbComName.Location = new System.Drawing.Point(97, 63);
            this.cbComName.Margin = new System.Windows.Forms.Padding(4);
            this.cbComName.Name = "cbComName";
            this.cbComName.Size = new System.Drawing.Size(72, 25);
            this.cbComName.TabIndex = 0;
            // 
            // cbSeclectCom
            // 
            this.cbSeclectCom.FormattingEnabled = true;
            this.cbSeclectCom.Location = new System.Drawing.Point(12, 22);
            this.cbSeclectCom.Margin = new System.Windows.Forms.Padding(4);
            this.cbSeclectCom.Name = "cbSeclectCom";
            this.cbSeclectCom.Size = new System.Drawing.Size(356, 25);
            this.cbSeclectCom.TabIndex = 0;
            this.cbSeclectCom.SelectedIndexChanged += new System.EventHandler(this.cbSeclectCom_SelectedIndexChanged);
            // 
            // TimerGraph
            // 
            this.TimerGraph.Tick += new System.EventHandler(this.TimerGraph_Tick);
            // 
            // gbControl
            // 
            this.gbControl.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbControl.Controls.Add(this.btnShowVelData);
            this.gbControl.Controls.Add(this.btnShowPosData);
            this.gbControl.Controls.Add(this.btPause);
            this.gbControl.Controls.Add(this.btExit);
            this.gbControl.Controls.Add(this.btScale);
            this.gbControl.Controls.Add(this.btStart);
            this.gbControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbControl.Location = new System.Drawing.Point(949, 614);
            this.gbControl.Margin = new System.Windows.Forms.Padding(4);
            this.gbControl.Name = "gbControl";
            this.gbControl.Padding = new System.Windows.Forms.Padding(4);
            this.gbControl.Size = new System.Drawing.Size(385, 151);
            this.gbControl.TabIndex = 3;
            this.gbControl.TabStop = false;
            this.gbControl.Text = "Control";
            // 
            // btnShowVelData
            // 
            this.btnShowVelData.BackColor = System.Drawing.Color.BurlyWood;
            this.btnShowVelData.Location = new System.Drawing.Point(8, 88);
            this.btnShowVelData.Name = "btnShowVelData";
            this.btnShowVelData.Size = new System.Drawing.Size(120, 50);
            this.btnShowVelData.TabIndex = 62;
            this.btnShowVelData.Text = "Veldata";
            this.btnShowVelData.UseVisualStyleBackColor = false;
            this.btnShowVelData.Click += new System.EventHandler(this.btnShowVelData_Click);
            // 
            // btnShowPosData
            // 
            this.btnShowPosData.BackColor = System.Drawing.Color.DarkGray;
            this.btnShowPosData.Location = new System.Drawing.Point(134, 88);
            this.btnShowPosData.Name = "btnShowPosData";
            this.btnShowPosData.Size = new System.Drawing.Size(120, 50);
            this.btnShowPosData.TabIndex = 61;
            this.btnShowPosData.Text = "Posdata";
            this.btnShowPosData.UseVisualStyleBackColor = false;
            this.btnShowPosData.Click += new System.EventHandler(this.btnShowPosData_Click);
            // 
            // btPause
            // 
            this.btPause.BackColor = System.Drawing.Color.Gold;
            this.btPause.Location = new System.Drawing.Point(133, 31);
            this.btPause.Margin = new System.Windows.Forms.Padding(4);
            this.btPause.Name = "btPause";
            this.btPause.Size = new System.Drawing.Size(120, 50);
            this.btPause.TabIndex = 1;
            this.btPause.Text = "Pause";
            this.btPause.UseVisualStyleBackColor = false;
            this.btPause.Click += new System.EventHandler(this.btPause_Click);
            // 
            // btExit
            // 
            this.btExit.BackColor = System.Drawing.Color.Tomato;
            this.btExit.Location = new System.Drawing.Point(261, 88);
            this.btExit.Margin = new System.Windows.Forms.Padding(4);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(120, 50);
            this.btExit.TabIndex = 0;
            this.btExit.Text = "Exit";
            this.btExit.UseVisualStyleBackColor = false;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btScale
            // 
            this.btScale.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btScale.Location = new System.Drawing.Point(261, 31);
            this.btScale.Margin = new System.Windows.Forms.Padding(4);
            this.btScale.Name = "btScale";
            this.btScale.Size = new System.Drawing.Size(120, 50);
            this.btScale.TabIndex = 0;
            this.btScale.Text = "Back";
            this.btScale.UseVisualStyleBackColor = false;
            this.btScale.Click += new System.EventHandler(this.btScale_Click);
            // 
            // btStart
            // 
            this.btStart.BackColor = System.Drawing.Color.PaleGreen;
            this.btStart.Location = new System.Drawing.Point(8, 31);
            this.btStart.Margin = new System.Windows.Forms.Padding(4);
            this.btStart.Name = "btStart";
            this.btStart.Size = new System.Drawing.Size(120, 50);
            this.btStart.TabIndex = 0;
            this.btStart.Text = "Start";
            this.btStart.UseVisualStyleBackColor = false;
            this.btStart.Click += new System.EventHandler(this.btStart_Click);
            // 
            // grbSetVel
            // 
            this.grbSetVel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grbSetVel.Controls.Add(this.label6);
            this.grbSetVel.Controls.Add(this.label4);
            this.grbSetVel.Controls.Add(this.btReSet);
            this.grbSetVel.Controls.Add(this.btSetPoint);
            this.grbSetVel.Controls.Add(this.txtVelocity);
            this.grbSetVel.Controls.Add(this.txtPosition);
            this.grbSetVel.Controls.Add(this.rbtVelocity);
            this.grbSetVel.Controls.Add(this.rbtPosition);
            this.grbSetVel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grbSetVel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSetVel.ForeColor = System.Drawing.Color.Black;
            this.grbSetVel.Location = new System.Drawing.Point(944, 285);
            this.grbSetVel.Margin = new System.Windows.Forms.Padding(4);
            this.grbSetVel.Name = "grbSetVel";
            this.grbSetVel.Padding = new System.Windows.Forms.Padding(4);
            this.grbSetVel.Size = new System.Drawing.Size(380, 122);
            this.grbSetVel.TabIndex = 51;
            this.grbSetVel.TabStop = false;
            this.grbSetVel.Text = "Set point";
            this.grbSetVel.Enter += new System.EventHandler(this.grbSetVel_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(176, 79);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 20);
            this.label6.TabIndex = 52;
            this.label6.Text = "(rad/s)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(175, 32);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "(mm)";
            // 
            // btReSet
            // 
            this.btReSet.Location = new System.Drawing.Point(251, 69);
            this.btReSet.Margin = new System.Windows.Forms.Padding(4);
            this.btReSet.Name = "btReSet";
            this.btReSet.Size = new System.Drawing.Size(100, 37);
            this.btReSet.TabIndex = 49;
            this.btReSet.Text = "Reset";
            this.btReSet.UseVisualStyleBackColor = true;
            this.btReSet.Click += new System.EventHandler(this.btReSet_Click);
            // 
            // btSetPoint
            // 
            this.btSetPoint.Location = new System.Drawing.Point(251, 25);
            this.btSetPoint.Margin = new System.Windows.Forms.Padding(4);
            this.btSetPoint.Name = "btSetPoint";
            this.btSetPoint.Size = new System.Drawing.Size(100, 37);
            this.btSetPoint.TabIndex = 47;
            this.btSetPoint.Text = "Set";
            this.btSetPoint.UseVisualStyleBackColor = true;
            this.btSetPoint.Click += new System.EventHandler(this.btSetPoint_Click);
            // 
            // txtVelocity
            // 
            this.txtVelocity.Location = new System.Drawing.Point(79, 74);
            this.txtVelocity.Margin = new System.Windows.Forms.Padding(4);
            this.txtVelocity.Name = "txtVelocity";
            this.txtVelocity.Size = new System.Drawing.Size(93, 30);
            this.txtVelocity.TabIndex = 46;
            this.txtVelocity.TextChanged += new System.EventHandler(this.txtVelocity_TextChanged);
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(79, 28);
            this.txtPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(93, 30);
            this.txtPosition.TabIndex = 45;
            this.txtPosition.TextChanged += new System.EventHandler(this.txtPosition_TextChanged);
            // 
            // rbtVelocity
            // 
            this.rbtVelocity.AutoSize = true;
            this.rbtVelocity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtVelocity.ForeColor = System.Drawing.Color.Black;
            this.rbtVelocity.Location = new System.Drawing.Point(5, 76);
            this.rbtVelocity.Margin = new System.Windows.Forms.Padding(4);
            this.rbtVelocity.Name = "rbtVelocity";
            this.rbtVelocity.Size = new System.Drawing.Size(64, 28);
            this.rbtVelocity.TabIndex = 0;
            this.rbtVelocity.Text = "Vel.";
            this.rbtVelocity.UseVisualStyleBackColor = true;
            this.rbtVelocity.CheckedChanged += new System.EventHandler(this.rbtVelocity_CheckedChanged);
            // 
            // rbtPosition
            // 
            this.rbtPosition.AutoSize = true;
            this.rbtPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtPosition.ForeColor = System.Drawing.Color.Black;
            this.rbtPosition.Location = new System.Drawing.Point(5, 30);
            this.rbtPosition.Margin = new System.Windows.Forms.Padding(4);
            this.rbtPosition.Name = "rbtPosition";
            this.rbtPosition.Size = new System.Drawing.Size(68, 28);
            this.rbtPosition.TabIndex = 0;
            this.rbtPosition.Text = "Pos.";
            this.rbtPosition.UseVisualStyleBackColor = true;
            this.rbtPosition.CheckedChanged += new System.EventHandler(this.rbtPosition_CheckedChanged);
            // 
            // gbCurrent
            // 
            this.gbCurrent.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbCurrent.Controls.Add(this.groupBox2);
            this.gbCurrent.Controls.Add(this.txtUd);
            this.gbCurrent.Controls.Add(this.label8);
            this.gbCurrent.Controls.Add(this.txtUq);
            this.gbCurrent.Controls.Add(this.label10);
            this.gbCurrent.Controls.Add(this.label37);
            this.gbCurrent.Controls.Add(this.label38);
            this.gbCurrent.Controls.Add(this.txtVel);
            this.gbCurrent.Controls.Add(this.txtPos);
            this.gbCurrent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCurrent.ForeColor = System.Drawing.Color.Black;
            this.gbCurrent.Location = new System.Drawing.Point(948, 415);
            this.gbCurrent.Margin = new System.Windows.Forms.Padding(4);
            this.gbCurrent.Name = "gbCurrent";
            this.gbCurrent.Padding = new System.Windows.Forms.Padding(4);
            this.gbCurrent.Size = new System.Drawing.Size(380, 191);
            this.gbCurrent.TabIndex = 52;
            this.gbCurrent.TabStop = false;
            this.gbCurrent.Text = "Current Values";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.Controls.Add(this.CalibFirst);
            this.groupBox2.Controls.Add(this.CalibFail);
            this.groupBox2.Controls.Add(this.CalibDone);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(219, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(148, 169);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calib Status";
            // 
            // CalibFirst
            // 
            this.CalibFirst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CalibFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalibFirst.Location = new System.Drawing.Point(27, 53);
            this.CalibFirst.Margin = new System.Windows.Forms.Padding(4);
            this.CalibFirst.Name = "CalibFirst";
            this.CalibFirst.Size = new System.Drawing.Size(100, 89);
            this.CalibFirst.TabIndex = 61;
            this.CalibFirst.UseVisualStyleBackColor = false;
            // 
            // CalibFail
            // 
            this.CalibFail.BackColor = System.Drawing.Color.OrangeRed;
            this.CalibFail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalibFail.Location = new System.Drawing.Point(29, 53);
            this.CalibFail.Margin = new System.Windows.Forms.Padding(4);
            this.CalibFail.Name = "CalibFail";
            this.CalibFail.Size = new System.Drawing.Size(100, 89);
            this.CalibFail.TabIndex = 60;
            this.CalibFail.Text = "Fail!";
            this.CalibFail.UseVisualStyleBackColor = false;
            this.CalibFail.Visible = false;
            this.CalibFail.Click += new System.EventHandler(this.CalibFail_Click);
            // 
            // CalibDone
            // 
            this.CalibDone.BackColor = System.Drawing.Color.LimeGreen;
            this.CalibDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalibDone.Location = new System.Drawing.Point(27, 53);
            this.CalibDone.Margin = new System.Windows.Forms.Padding(4);
            this.CalibDone.Name = "CalibDone";
            this.CalibDone.Size = new System.Drawing.Size(100, 89);
            this.CalibDone.TabIndex = 59;
            this.CalibDone.Text = "Done";
            this.CalibDone.UseVisualStyleBackColor = false;
            this.CalibDone.Visible = false;
            // 
            // txtUd
            // 
            this.txtUd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(175)))));
            this.txtUd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUd.Enabled = false;
            this.txtUd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUd.ForeColor = System.Drawing.Color.Black;
            this.txtUd.Location = new System.Drawing.Point(97, 142);
            this.txtUd.Margin = new System.Windows.Forms.Padding(4);
            this.txtUd.Name = "txtUd";
            this.txtUd.Size = new System.Drawing.Size(95, 26);
            this.txtUd.TabIndex = 50;
            this.txtUd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtUd.TextChanged += new System.EventHandler(this.txtUd_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(9, 142);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 24);
            this.label8.TabIndex = 49;
            this.label8.Text = "Ud";
            // 
            // txtUq
            // 
            this.txtUq.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(175)))));
            this.txtUq.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUq.Enabled = false;
            this.txtUq.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUq.ForeColor = System.Drawing.Color.Black;
            this.txtUq.Location = new System.Drawing.Point(96, 107);
            this.txtUq.Margin = new System.Windows.Forms.Padding(4);
            this.txtUq.Name = "txtUq";
            this.txtUq.Size = new System.Drawing.Size(95, 26);
            this.txtUq.TabIndex = 48;
            this.txtUq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(9, 107);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 24);
            this.label10.TabIndex = 46;
            this.label10.Text = "Uq";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(4, 73);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(81, 24);
            this.label37.TabIndex = 24;
            this.label37.Text = "V (rad/s)";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(1, 39);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(86, 24);
            this.label38.TabIndex = 23;
            this.label38.Text = "Pos(mm)";
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // txtVel
            // 
            this.txtVel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(175)))));
            this.txtVel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVel.Enabled = false;
            this.txtVel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVel.ForeColor = System.Drawing.Color.Black;
            this.txtVel.Location = new System.Drawing.Point(97, 73);
            this.txtVel.Margin = new System.Windows.Forms.Padding(4);
            this.txtVel.Name = "txtVel";
            this.txtVel.Size = new System.Drawing.Size(95, 26);
            this.txtVel.TabIndex = 0;
            this.txtVel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPos
            // 
            this.txtPos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(175)))));
            this.txtPos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPos.Enabled = false;
            this.txtPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPos.ForeColor = System.Drawing.Color.Black;
            this.txtPos.Location = new System.Drawing.Point(96, 38);
            this.txtPos.Margin = new System.Windows.Forms.Padding(4);
            this.txtPos.Name = "txtPos";
            this.txtPos.Size = new System.Drawing.Size(95, 26);
            this.txtPos.TabIndex = 0;
            this.txtPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPos.TextChanged += new System.EventHandler(this.txtPos_TextChanged);
            // 
            // txtKdSet
            // 
            this.txtKdSet.Location = new System.Drawing.Point(0, 0);
            this.txtKdSet.Name = "txtKdSet";
            this.txtKdSet.Size = new System.Drawing.Size(100, 22);
            this.txtKdSet.TabIndex = 0;
            // 
            // txtKiSet
            // 
            this.txtKiSet.Location = new System.Drawing.Point(0, 0);
            this.txtKiSet.Name = "txtKiSet";
            this.txtKiSet.Size = new System.Drawing.Size(100, 22);
            this.txtKiSet.TabIndex = 0;
            // 
            // txtKpSet
            // 
            this.txtKpSet.Location = new System.Drawing.Point(0, 0);
            this.txtKpSet.Name = "txtKpSet";
            this.txtKpSet.Size = new System.Drawing.Size(100, 22);
            this.txtKpSet.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 0;
            // 
            // bkgdWorker
            // 
            this.bkgdWorker.WorkerSupportsCancellation = true;
            this.bkgdWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkgdWorker_DoWork);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(916, 124);
            this.label5.TabIndex = 56;
            this.label5.Text = "TRƯỜNG ĐẠI HỌC SƯ PHẠM KỸ THUẬT TPHCM\r\nKHOA CƠ KHÍ CHẾ TẠO MÁY\r\nBỘ MÔN: CƠ ĐIỆN T" +
    "Ử\r\n\r\n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(285, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 57;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::DC.Properties.Resources.FME1;
            this.pictureBox2.Location = new System.Drawing.Point(1140, 11);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(171, 161);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.statusBox);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(13, 135);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(923, 194);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Status";
            // 
            // statusBox
            // 
            this.statusBox.BackColor = System.Drawing.SystemColors.Info;
            this.statusBox.Location = new System.Drawing.Point(12, 30);
            this.statusBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.statusBox.Multiline = true;
            this.statusBox.Name = "statusBox";
            this.statusBox.Size = new System.Drawing.Size(903, 158);
            this.statusBox.TabIndex = 0;
            this.statusBox.TextChanged += new System.EventHandler(this.statusBox_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DC.Properties.Resources.HCMUTE1;
            this.pictureBox1.Location = new System.Drawing.Point(948, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(173, 161);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 55;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(916, 30);
            this.label9.TabIndex = 59;
            this.label9.Text = "ĐIỀU KHIỂN ĐỘNG CƠ BLDC SỬ DỤNG ENCODER\r\n";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuStripPosGraph
            // 
            this.contextMenuStripPosGraph.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStripPosGraph.Name = "contextMenuStrip1";
            this.contextMenuStripPosGraph.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.btnResetRamp);
            this.groupBox3.Controls.Add(this.btnSetRamp);
            this.groupBox3.Controls.Add(this.txtTimeRamp);
            this.groupBox3.Controls.Add(this.txtPosRamp);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(948, 773);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(380, 108);
            this.groupBox3.TabIndex = 53;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ramp function";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(16, 67);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 24);
            this.label14.TabIndex = 54;
            this.label14.Text = "Time";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(13, 33);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 24);
            this.label13.TabIndex = 53;
            this.label13.Text = "Position";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(201, 70);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 20);
            this.label11.TabIndex = 52;
            this.label11.Text = "(s)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(194, 32);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 20);
            this.label12.TabIndex = 50;
            this.label12.Text = "(mm)";
            // 
            // btnResetRamp
            // 
            this.btnResetRamp.Location = new System.Drawing.Point(251, 63);
            this.btnResetRamp.Margin = new System.Windows.Forms.Padding(4);
            this.btnResetRamp.Name = "btnResetRamp";
            this.btnResetRamp.Size = new System.Drawing.Size(100, 37);
            this.btnResetRamp.TabIndex = 49;
            this.btnResetRamp.Text = "Reset";
            this.btnResetRamp.UseVisualStyleBackColor = true;
            this.btnResetRamp.Click += new System.EventHandler(this.btnResetRamp_Click);
            // 
            // btnSetRamp
            // 
            this.btnSetRamp.Location = new System.Drawing.Point(251, 25);
            this.btnSetRamp.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetRamp.Name = "btnSetRamp";
            this.btnSetRamp.Size = new System.Drawing.Size(100, 37);
            this.btnSetRamp.TabIndex = 47;
            this.btnSetRamp.Text = "Set";
            this.btnSetRamp.UseVisualStyleBackColor = true;
            this.btnSetRamp.Click += new System.EventHandler(this.btnSetRamp_Click);
            // 
            // txtTimeRamp
            // 
            this.txtTimeRamp.Location = new System.Drawing.Point(97, 66);
            this.txtTimeRamp.Margin = new System.Windows.Forms.Padding(4);
            this.txtTimeRamp.Name = "txtTimeRamp";
            this.txtTimeRamp.Size = new System.Drawing.Size(93, 30);
            this.txtTimeRamp.TabIndex = 46;
            this.txtTimeRamp.TextChanged += new System.EventHandler(this.txtTimeRamp_TextChanged);
            // 
            // txtPosRamp
            // 
            this.txtPosRamp.Location = new System.Drawing.Point(97, 29);
            this.txtPosRamp.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosRamp.Name = "txtPosRamp";
            this.txtPosRamp.Size = new System.Drawing.Size(93, 30);
            this.txtPosRamp.TabIndex = 45;
            this.txtPosRamp.TextChanged += new System.EventHandler(this.txtPosRamp_TextChanged);
            // 
            // EncoderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 888);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.grbSetVel);
            this.Controls.Add(this.gbCurrent);
            this.Controls.Add(this.gbControl);
            this.Controls.Add(this.gbConnect);
            this.Controls.Add(this.GraphVel);
            this.Controls.Add(this.GraphPos);
            this.Controls.Add(this.label5);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "EncoderForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Encoder BLDC";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EncoderForm_FormClosing);
            this.Load += new System.EventHandler(this.EncoderForm_Load);
            this.gbConnect.ResumeLayout(false);
            this.gbControl.ResumeLayout(false);
            this.grbSetVel.ResumeLayout(false);
            this.grbSetVel.PerformLayout();
            this.gbCurrent.ResumeLayout(false);
            this.gbCurrent.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort SerialPort;
        private System.Windows.Forms.Timer TimerPort;
        private ZedGraph.ZedGraphControl GraphPos;
        private ZedGraph.ZedGraphControl GraphVel;
        private System.Windows.Forms.GroupBox gbConnect;
        private System.Windows.Forms.Button btDisconnect;
        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.ComboBox cbSeclectCom;
        private System.Windows.Forms.Timer TimerGraph;
        private System.Windows.Forms.ComboBox cbComName;
        private System.Windows.Forms.GroupBox gbControl;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btScale;
        private System.Windows.Forms.Button btStart;
        private System.Windows.Forms.GroupBox grbSetVel;
        private System.Windows.Forms.GroupBox gbCurrent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtVelocity;
        private System.Windows.Forms.Button btSetPoint;
        private System.Windows.Forms.TextBox txtKpSet;
        private System.Windows.Forms.TextBox txtKdSet;
        private System.Windows.Forms.TextBox txtKiSet;
        private System.Windows.Forms.Button btReSet;
        private System.ComponentModel.BackgroundWorker bkgdWorker;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox statusBox;
        protected System.Windows.Forms.Button btPause;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rbtVelocity;
        private System.Windows.Forms.RadioButton rbtPosition;
        private System.Windows.Forms.TextBox txtUd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUq;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtVel;
        private System.Windows.Forms.TextBox txtPos;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button CalibFail;
        private System.Windows.Forms.Button CalibDone;
        private System.Windows.Forms.Button CalibFirst;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripPosGraph;
        private System.Windows.Forms.Button btnShowPosData;
        private System.Windows.Forms.Button btnShowVelData;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnResetRamp;
        private System.Windows.Forms.Button btnSetRamp;
        private System.Windows.Forms.TextBox txtTimeRamp;
        private System.Windows.Forms.TextBox txtPosRamp;
    }
}

