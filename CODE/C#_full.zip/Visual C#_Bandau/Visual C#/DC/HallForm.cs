﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.IO.Ports;
using ZedGraph;
using System.Management;
using System.Diagnostics;



namespace DC
{
    public partial class HallForm : Form
    {
        private int _mode;
        public HallForm(int mode)
        {
            _mode = mode; // Lưu lại để sử dụng
            InitializeComponent();
        }

        private void HallForm_Load(object sender, EventArgs e)
        {
            SerialPort_Initialize();
            ZedGraph_Initialize();
            txtPWM.Enabled = true;

            //setup timergraph
            TimerGraph.Enabled = false;
            TimerGraph.Tick += new EventHandler(TimerGraph_Tick);
            TimerGraph.Interval = 100;
            TimerGraph.Stop();
            //setup timerport
            TimerPort.Enabled = true;
            TimerPort.Tick += new EventHandler(TimerPort_Tick);
            TimerPort.Interval = 100;
            TimerPort.Start();
        }

        private void SerialPort_Initialize()
        {
            //Baud Rate
            cbBaudRate.Items.Add(19200);
            cbBaudRate.Items.Add(38400);
            cbBaudRate.Items.Add(57600);
            cbBaudRate.Items.Add(115200);
            cbBaudRate.Items.Add(128000);
            cbBaudRate.Items.Add(256000);
            cbBaudRate.Items.ToString();
            //get first item print in text
            cbBaudRate.Text = cbBaudRate.Items[3].ToString();
        }

        int SumPort = 0;
        private void TimerPort_Tick(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            if (SumPort != ports.Length)
            {
                SumPort = ports.Length;
                cbSeclectCom.Items.Clear();
                foreach (COMPortInfo PortCOMs in COMPortInfo.GetCOMPortsInfo())
                {
                    cbSeclectCom.Items.Add(string.Format("{0} – {1}", PortCOMs.Name, PortCOMs.Description));
                    cbComName.Items.Add(PortCOMs.Name);
                }
                cbSeclectCom.SelectedIndex = 0;
                cbComName.SelectedIndex = 0;
            }
        }
        /* khoi tao do thi */
        private void ZedGraph_Initialize()
        {
            GraphPane VelPane = GraphVel.GraphPane;

            // Thiết lập font và tiêu đề
            VelPane.Title.FontSpec.Size = 12;
            VelPane.XAxis.Title.FontSpec.Size = 12;
            VelPane.YAxis.Title.FontSpec.Size = 12;
            VelPane.Title.Text = "PWM Graph";
            VelPane.XAxis.Title.Text = "Time (s)";
            VelPane.YAxis.Title.Text = "PWM Value";

            VelPane.Chart.Fill = new Fill(Color.White, Color.FromArgb(255, 236, 179), 45.0f); // LightOrange
            VelPane.Fill = new Fill(Color.White, Color.White, 45.0f);

            // Lưới đồ thị
            VelPane.XAxis.MajorGrid.IsVisible = true;
            VelPane.YAxis.MajorGrid.IsVisible = true;
            VelPane.XAxis.MajorGrid.Color = Color.LightGray;
            VelPane.YAxis.MajorGrid.Color = Color.LightGray;

            // Tạo đường đồ thị với màu sắc mới
            RollingPointPairList list = new RollingPointPairList(60000);
            LineItem curve = VelPane.AddCurve("PWM", list, Color.FromArgb(0, 100, 200), SymbolType.None); // Xanh dương đậm

            // Tùy chỉnh đường
            curve.Line.Width = 2.0f; // Độ rộng đường
            curve.Line.Style = System.Drawing.Drawing2D.DashStyle.Solid;

            // Thiết lập trục
            VelPane.XAxis.Scale.Max = 30;
            VelPane.XAxis.Scale.MinorStep = 0;
            VelPane.XAxis.Scale.MajorStep = 100;
            VelPane.YAxis.Scale.MaxAuto = true;
            VelPane.YAxis.Scale.MinAuto = true;

            GraphVel.AxisChange();
        }


        /* -------------------------------- Vẽ đồ thị---------------------------------- */
        int tickStart = 0;
        double pos, vel, set_pos, set_vel, mv;
        bool scroll = true, check = true;

        public void ZedGraph_Draw()
        {
            if (GraphVel.GraphPane.CurveList.Count <= 0)
                return;

            LineItem curve = GraphVel.GraphPane.CurveList[0] as LineItem;
            if (curve == null)
                return;

            IPointListEdit list = curve.Points as IPointListEdit;
            if (list == null)
                return;

            double time = (Environment.TickCount - tickStart) / 1000.0;

            // Thêm điểm dữ liệu mới
            list.Add(time, currentPWM);

            // Tự động cuộn đồ thị
            Scale xScale = GraphVel.GraphPane.XAxis.Scale;
            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - 30.0;
            }

            // Tự động điều chỉnh trục Y
            GraphVel.AxisChange();
            GraphVel.Invalidate();
        }

        private void btConnect_Click(object sender, EventArgs e)
        {
            try
            {
                SerialPort.PortName = Convert.ToString(cbComName.Text);
                SerialPort.BaudRate = Convert.ToInt32(cbBaudRate.Text);
                SerialPort.DataBits = 8;
                SerialPort.StopBits = StopBits.One;
                SerialPort.Handshake = Handshake.None;
                SerialPort.Parity = Parity.None;
                SerialPort.Open();
                gbConnect.Text = cbSeclectCom.SelectedItem.ToString();
                TimerPort.Enabled = false;
                //Run BackgroundWorker
                if (!bkgdWorker.IsBusy) { bkgdWorker.RunWorkerAsync(); }

                System.Threading.Thread.Sleep(1000);
                tickStart = Environment.TickCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            DialogResult msg;
            msg = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (msg == DialogResult.Yes)
            {
                TimerGraph.Stop();
                SerialPort.Close();
                //this.Close();
                Application.Exit();
            }

        }

        private void btScale_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btStart_Click(object sender, EventArgs e)
        {
            try
            {
                SerialPort.Write("r");
                SerialPort.WriteLine("GET_STATUS"); // Yêu cầu gửi trạng thái hiện tại

                if (GraphVel.GraphPane.CurveList.Count == 0)
                    ZedGraph_Initialize();

                tickStart = Environment.TickCount;
                TimerGraph.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        string InputData = String.Empty;
        private void bkgdWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (!bkgdWorker.CancellationPending)
            {
                if (SerialPort.IsOpen)
                {
                    try
                    {
                        string data = SerialPort.ReadLine();
                        if (!string.IsNullOrEmpty(data))
                        {
                            this.Invoke(new Action(() =>
                            {
                                if (data.StartsWith("STATUS:PWM:"))
                                {
                                    // Xử lý chuỗi STATUS:PWM:50,DIR:0
                                    var parts = data.Split(new[] { ':', ',' });
                                    if (parts.Length >= 4)
                                    {
                                        if (int.TryParse(parts[2], out int pwm))
                                        {
                                            currentPWM = pwm;
                                            txtPWM.Text = currentPWM.ToString();
                                        }
                                        if (int.TryParse(parts[4], out int dir))
                                        {
                                            currentDir = dir;
                                            // Cập nhật UI nếu cần
                                        }
                                    }
                                }
                                else if (data.StartsWith("PWM:"))
                                {
                                    // Giữ lại xử lý cũ để tương thích
                                    if (double.TryParse(data.Substring(4), out double newPwm))
                                    {
                                        currentPWM = newPwm;
                                        txtPWM.Text = currentPWM.ToString("0");
                                    }
                                }
                            }));
                        }
                    }
                    catch (TimeoutException) { /* Bỏ qua timeout */ }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Lỗi đọc serial: {ex.Message}");
                    }
                }
            }
        }



        private void btSetPoint_Click(object sender, EventArgs e)
        {
            try
            {
                // Đọc giá trị từ txtPWM
                int pwmValue = int.Parse(txtPWM.Text);

                // Gửi giá trị PWM sang STM32 qua cổng Serial
                SerialPort.WriteLine(pwmValue.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nhập sai hoặc chưa nhập giá trị PWM!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        double currentPWM = 0; // khai báo toàn cục
       

        delegate void SetPWMCallback(string text);
        private void SetPWM(string data)
        {
            try
            {
                data = data.Trim();
                currentPWM = double.Parse(data); // Cập nhật biến để vẽ đồ thị
            }
            catch
            {
                // Có thể bỏ qua lỗi nếu dữ liệu không hợp lệ
            }
        }



        private void btReSet_Click(object sender, EventArgs e)
        {
            try
            {
                // Đặt giá trị PWM = 0
                currentPWM = 0;
                txtPWM.Text = "0";

                // Gửi giá trị 0 xuống STM32
                SerialPort.WriteLine("0");

                // Nếu muốn gửi kèm lệnh stop (tùy chọn)
                // SerialPort.Write("e"); 

                // Cập nhật đồ thị ngay lập tức
                if (TimerGraph.Enabled)
                {
                    ZedGraph_Draw();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int currentDir = 0; // 0=CW, 1=CCW
        private void UpdateDirectionUI()
        {
            // Cập nhật giao diện theo currentDir
            btnCW.BackColor = currentDir == 0 ? Color.LightGreen : SystemColors.Control;
            btnCCW.BackColor = currentDir == 1 ? Color.LightGreen : SystemColors.Control;
        }

        private void btnCW_Click(object sender, EventArgs e)
        {
            try
            {
                if (SerialPort.IsOpen)
                {
                    SerialPort.WriteLine("CW");
                    currentDir = 0;
                    UpdateDirectionUI();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi gửi lệnh: " + ex.Message);
            }
        }

        private void btnCCW_Click(object sender, EventArgs e)
        {
            try
            {
                if (SerialPort.IsOpen)
                {
                    SerialPort.WriteLine("CCW");
                    currentDir = 1;
                    UpdateDirectionUI();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi gửi lệnh: " + ex.Message);
            }
        }
        private void btStop_Click(object sender, EventArgs e)
        {
            try
            {
                SerialPort.Write("e");
                TimerGraph.Stop();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void grbSetVel_Enter(object sender, EventArgs e)
        {

        }
  

        private void GraphVel_Load(object sender, EventArgs e)
        {

        }


        private void label5_Click(object sender, EventArgs e)
        {

        }


        private void txtVelocity_TextChanged(object sender, EventArgs e)
        {

        }

        private void gbConnect_Enter(object sender, EventArgs e)
        {

        }

        private void rbtVelocity_CheckedChanged(object sender, EventArgs e)
        {

        }

        double errPos = 0;
        private void TimerGraph_Tick(object sender, EventArgs e)
        {
            try
            {
                ZedGraph_Draw();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Lỗi vẽ đồ thị: {ex.Message}");
            }
        }

        private void cbSeclectCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbComName.SelectedIndex = cbSeclectCom.SelectedIndex;
        }

        private void btDisconnect_Click(object sender, EventArgs e)
        {
            gbConnect.Text = "Disconnect";
            TimerGraph.Stop();                           //Stop timer(s), whatever it takes
            TimerPort.Enabled = true;                    // Start timer to scan port   

            bkgdWorker.CancelAsync();
            System.Threading.Thread.Sleep(500);         //Wait bkworker to finish
            SerialPort.Close();
        }

        private void HallForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult msg;
            msg = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (msg == DialogResult.Yes)
            {
                SerialPort.Close();
                TimerGraph.Stop();
                e.Cancel = false;
            }
            else e.Cancel = true;
        }
    }
}
