﻿namespace DC
{
    partial class HallForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SerialPort = new System.IO.Ports.SerialPort(this.components);
            this.TimerPort = new System.Windows.Forms.Timer(this.components);
            this.gbConnect = new System.Windows.Forms.GroupBox();
            this.btDisconnect = new System.Windows.Forms.Button();
            this.btConnect = new System.Windows.Forms.Button();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.cbComName = new System.Windows.Forms.ComboBox();
            this.cbSeclectCom = new System.Windows.Forms.ComboBox();
            this.TimerGraph = new System.Windows.Forms.Timer(this.components);
            this.gbControl = new System.Windows.Forms.GroupBox();
            this.btExit = new System.Windows.Forms.Button();
            this.btScale = new System.Windows.Forms.Button();
            this.btStop = new System.Windows.Forms.Button();
            this.btStart = new System.Windows.Forms.Button();
            this.grbSetVel = new System.Windows.Forms.GroupBox();
            this.btReSet = new System.Windows.Forms.Button();
            this.btSetPoint = new System.Windows.Forms.Button();
            this.txtPWM = new System.Windows.Forms.TextBox();
            this.rbtVelocity = new System.Windows.Forms.RadioButton();
            this.txtKdSet = new System.Windows.Forms.TextBox();
            this.txtKiSet = new System.Windows.Forms.TextBox();
            this.txtKpSet = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bkgdWorker = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GraphVel = new ZedGraph.ZedGraphControl();
            this.grpSetDir = new System.Windows.Forms.GroupBox();
            this.btnCCW = new System.Windows.Forms.Button();
            this.btnCW = new System.Windows.Forms.Button();
            this.gbConnect.SuspendLayout();
            this.gbControl.SuspendLayout();
            this.grbSetVel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpSetDir.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbConnect
            // 
            this.gbConnect.Controls.Add(this.btDisconnect);
            this.gbConnect.Controls.Add(this.btConnect);
            this.gbConnect.Controls.Add(this.cbBaudRate);
            this.gbConnect.Controls.Add(this.cbComName);
            this.gbConnect.Controls.Add(this.cbSeclectCom);
            this.gbConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbConnect.Location = new System.Drawing.Point(948, 182);
            this.gbConnect.Margin = new System.Windows.Forms.Padding(4);
            this.gbConnect.Name = "gbConnect";
            this.gbConnect.Padding = new System.Windows.Forms.Padding(4);
            this.gbConnect.Size = new System.Drawing.Size(380, 105);
            this.gbConnect.TabIndex = 2;
            this.gbConnect.TabStop = false;
            this.gbConnect.Text = "Disconnect";
            this.gbConnect.Enter += new System.EventHandler(this.gbConnect_Enter);
            // 
            // btDisconnect
            // 
            this.btDisconnect.Location = new System.Drawing.Point(259, 58);
            this.btDisconnect.Margin = new System.Windows.Forms.Padding(4);
            this.btDisconnect.Name = "btDisconnect";
            this.btDisconnect.Size = new System.Drawing.Size(95, 39);
            this.btDisconnect.TabIndex = 1;
            this.btDisconnect.Text = "Disconnect";
            this.btDisconnect.UseVisualStyleBackColor = true;
            this.btDisconnect.Click += new System.EventHandler(this.btDisconnect_Click);
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(173, 58);
            this.btConnect.Margin = new System.Windows.Forms.Padding(4);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(84, 39);
            this.btConnect.TabIndex = 1;
            this.btConnect.Text = "Connect";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.Location = new System.Drawing.Point(12, 63);
            this.cbBaudRate.Margin = new System.Windows.Forms.Padding(4);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(76, 25);
            this.cbBaudRate.TabIndex = 0;
            // 
            // cbComName
            // 
            this.cbComName.FormattingEnabled = true;
            this.cbComName.Location = new System.Drawing.Point(97, 63);
            this.cbComName.Margin = new System.Windows.Forms.Padding(4);
            this.cbComName.Name = "cbComName";
            this.cbComName.Size = new System.Drawing.Size(72, 25);
            this.cbComName.TabIndex = 0;
            // 
            // cbSeclectCom
            // 
            this.cbSeclectCom.FormattingEnabled = true;
            this.cbSeclectCom.Location = new System.Drawing.Point(12, 22);
            this.cbSeclectCom.Margin = new System.Windows.Forms.Padding(4);
            this.cbSeclectCom.Name = "cbSeclectCom";
            this.cbSeclectCom.Size = new System.Drawing.Size(356, 25);
            this.cbSeclectCom.TabIndex = 0;
            this.cbSeclectCom.SelectedIndexChanged += new System.EventHandler(this.cbSeclectCom_SelectedIndexChanged);
            // 
            // TimerGraph
            // 
            this.TimerGraph.Tick += new System.EventHandler(this.TimerGraph_Tick);
            // 
            // gbControl
            // 
            this.gbControl.Controls.Add(this.btExit);
            this.gbControl.Controls.Add(this.btScale);
            this.gbControl.Controls.Add(this.btStop);
            this.gbControl.Controls.Add(this.btStart);
            this.gbControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbControl.Location = new System.Drawing.Point(960, 581);
            this.gbControl.Margin = new System.Windows.Forms.Padding(4);
            this.gbControl.Name = "gbControl";
            this.gbControl.Padding = new System.Windows.Forms.Padding(4);
            this.gbControl.Size = new System.Drawing.Size(375, 208);
            this.gbControl.TabIndex = 3;
            this.gbControl.TabStop = false;
            this.gbControl.Text = "Control";
            // 
            // btExit
            // 
            this.btExit.BackColor = System.Drawing.Color.Tomato;
            this.btExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExit.Location = new System.Drawing.Point(228, 133);
            this.btExit.Margin = new System.Windows.Forms.Padding(4);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(140, 60);
            this.btExit.TabIndex = 0;
            this.btExit.Text = "Exit";
            this.btExit.UseVisualStyleBackColor = false;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btScale
            // 
            this.btScale.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btScale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btScale.Location = new System.Drawing.Point(223, 31);
            this.btScale.Margin = new System.Windows.Forms.Padding(4);
            this.btScale.Name = "btScale";
            this.btScale.Size = new System.Drawing.Size(140, 60);
            this.btScale.TabIndex = 0;
            this.btScale.Text = "Back";
            this.btScale.UseVisualStyleBackColor = false;
            this.btScale.Click += new System.EventHandler(this.btScale_Click);
            // 
            // btStop
            // 
            this.btStop.BackColor = System.Drawing.Color.Yellow;
            this.btStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStop.Location = new System.Drawing.Point(8, 133);
            this.btStop.Margin = new System.Windows.Forms.Padding(4);
            this.btStop.Name = "btStop";
            this.btStop.Size = new System.Drawing.Size(140, 60);
            this.btStop.TabIndex = 0;
            this.btStop.Text = "Stop";
            this.btStop.UseVisualStyleBackColor = false;
            this.btStop.Click += new System.EventHandler(this.btStop_Click);
            // 
            // btStart
            // 
            this.btStart.BackColor = System.Drawing.Color.PaleGreen;
            this.btStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStart.Location = new System.Drawing.Point(8, 31);
            this.btStart.Margin = new System.Windows.Forms.Padding(4);
            this.btStart.Name = "btStart";
            this.btStart.Size = new System.Drawing.Size(140, 60);
            this.btStart.TabIndex = 0;
            this.btStart.Text = "Start";
            this.btStart.UseVisualStyleBackColor = false;
            this.btStart.Click += new System.EventHandler(this.btStart_Click);
            // 
            // grbSetVel
            // 
            this.grbSetVel.Controls.Add(this.btReSet);
            this.grbSetVel.Controls.Add(this.btSetPoint);
            this.grbSetVel.Controls.Add(this.txtPWM);
            this.grbSetVel.Controls.Add(this.rbtVelocity);
            this.grbSetVel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grbSetVel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSetVel.ForeColor = System.Drawing.Color.Black;
            this.grbSetVel.Location = new System.Drawing.Point(955, 304);
            this.grbSetVel.Margin = new System.Windows.Forms.Padding(4);
            this.grbSetVel.Name = "grbSetVel";
            this.grbSetVel.Padding = new System.Windows.Forms.Padding(4);
            this.grbSetVel.Size = new System.Drawing.Size(380, 164);
            this.grbSetVel.TabIndex = 51;
            this.grbSetVel.TabStop = false;
            this.grbSetVel.Text = "Set PWM";
            this.grbSetVel.Enter += new System.EventHandler(this.grbSetVel_Enter);
            // 
            // btReSet
            // 
            this.btReSet.Location = new System.Drawing.Point(222, 102);
            this.btReSet.Margin = new System.Windows.Forms.Padding(4);
            this.btReSet.Name = "btReSet";
            this.btReSet.Size = new System.Drawing.Size(139, 34);
            this.btReSet.TabIndex = 49;
            this.btReSet.Text = "Reset";
            this.btReSet.UseVisualStyleBackColor = true;
            this.btReSet.Click += new System.EventHandler(this.btReSet_Click);
            // 
            // btSetPoint
            // 
            this.btSetPoint.Location = new System.Drawing.Point(40, 102);
            this.btSetPoint.Margin = new System.Windows.Forms.Padding(4);
            this.btSetPoint.Name = "btSetPoint";
            this.btSetPoint.Size = new System.Drawing.Size(149, 36);
            this.btSetPoint.TabIndex = 47;
            this.btSetPoint.Text = "Set";
            this.btSetPoint.UseVisualStyleBackColor = true;
            this.btSetPoint.Click += new System.EventHandler(this.btSetPoint_Click);
            // 
            // txtPWM
            // 
            this.txtPWM.Location = new System.Drawing.Point(99, 48);
            this.txtPWM.Margin = new System.Windows.Forms.Padding(4);
            this.txtPWM.Name = "txtPWM";
            this.txtPWM.Size = new System.Drawing.Size(262, 30);
            this.txtPWM.TabIndex = 46;
            this.txtPWM.TextChanged += new System.EventHandler(this.txtVelocity_TextChanged);
            // 
            // rbtVelocity
            // 
            this.rbtVelocity.AutoSize = true;
            this.rbtVelocity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtVelocity.ForeColor = System.Drawing.Color.Black;
            this.rbtVelocity.Location = new System.Drawing.Point(5, 48);
            this.rbtVelocity.Margin = new System.Windows.Forms.Padding(4);
            this.rbtVelocity.Name = "rbtVelocity";
            this.rbtVelocity.Size = new System.Drawing.Size(76, 28);
            this.rbtVelocity.TabIndex = 0;
            this.rbtVelocity.Text = "value";
            this.rbtVelocity.UseVisualStyleBackColor = true;
            this.rbtVelocity.CheckedChanged += new System.EventHandler(this.rbtVelocity_CheckedChanged);
            // 
            // txtKdSet
            // 
            this.txtKdSet.Location = new System.Drawing.Point(0, 0);
            this.txtKdSet.Name = "txtKdSet";
            this.txtKdSet.Size = new System.Drawing.Size(100, 22);
            this.txtKdSet.TabIndex = 0;
            // 
            // txtKiSet
            // 
            this.txtKiSet.Location = new System.Drawing.Point(0, 0);
            this.txtKiSet.Name = "txtKiSet";
            this.txtKiSet.Size = new System.Drawing.Size(100, 22);
            this.txtKiSet.TabIndex = 0;
            // 
            // txtKpSet
            // 
            this.txtKpSet.Location = new System.Drawing.Point(0, 0);
            this.txtKpSet.Name = "txtKpSet";
            this.txtKpSet.Size = new System.Drawing.Size(100, 22);
            this.txtKpSet.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 0;
            // 
            // bkgdWorker
            // 
            this.bkgdWorker.WorkerSupportsCancellation = true;
            this.bkgdWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkgdWorker_DoWork);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(213, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(871, 167);
            this.label5.TabIndex = 56;
            this.label5.Text = "TRƯỜNG ĐẠI HỌC SƯ PHẠM KỸ THUẬT TPHCM\r\nKHOA CƠ KHÍ CHẾ TẠO MÁY\r\nBỘ MÔN: CƠ ĐIỆN T" +
    "Ử\r\n\r\nĐIỀU KHIỂN ĐỘNG CƠ BLDC SỬ DỤNG HALL\r\n\r\n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(285, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 57;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::DC.Properties.Resources.FME1;
            this.pictureBox2.Location = new System.Drawing.Point(1143, 5);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(180, 171);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DC.Properties.Resources.HCMUTE1;
            this.pictureBox1.Location = new System.Drawing.Point(9, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 167);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            // 
            // GraphVel
            // 
            this.GraphVel.Location = new System.Drawing.Point(9, 203);
            this.GraphVel.Margin = new System.Windows.Forms.Padding(5);
            this.GraphVel.Name = "GraphVel";
            this.GraphVel.ScrollGrace = 0D;
            this.GraphVel.ScrollMaxX = 0D;
            this.GraphVel.ScrollMaxY = 0D;
            this.GraphVel.ScrollMaxY2 = 0D;
            this.GraphVel.ScrollMinX = 0D;
            this.GraphVel.ScrollMinY = 0D;
            this.GraphVel.ScrollMinY2 = 0D;
            this.GraphVel.Size = new System.Drawing.Size(937, 586);
            this.GraphVel.TabIndex = 1;
            this.GraphVel.Load += new System.EventHandler(this.GraphVel_Load);
            // 
            // grpSetDir
            // 
            this.grpSetDir.Controls.Add(this.btnCCW);
            this.grpSetDir.Controls.Add(this.btnCW);
            this.grpSetDir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpSetDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSetDir.ForeColor = System.Drawing.Color.Black;
            this.grpSetDir.Location = new System.Drawing.Point(960, 476);
            this.grpSetDir.Margin = new System.Windows.Forms.Padding(4);
            this.grpSetDir.Name = "grpSetDir";
            this.grpSetDir.Padding = new System.Windows.Forms.Padding(4);
            this.grpSetDir.Size = new System.Drawing.Size(380, 97);
            this.grpSetDir.TabIndex = 52;
            this.grpSetDir.TabStop = false;
            this.grpSetDir.Text = "Direction";
            // 
            // btnCCW
            // 
            this.btnCCW.Location = new System.Drawing.Point(204, 33);
            this.btnCCW.Margin = new System.Windows.Forms.Padding(4);
            this.btnCCW.Name = "btnCCW";
            this.btnCCW.Size = new System.Drawing.Size(159, 56);
            this.btnCCW.TabIndex = 49;
            this.btnCCW.Text = "CCW";
            this.btnCCW.UseVisualStyleBackColor = true;
            this.btnCCW.Click += new System.EventHandler(this.btnCCW_Click);
            // 
            // btnCW
            // 
            this.btnCW.Location = new System.Drawing.Point(35, 33);
            this.btnCW.Margin = new System.Windows.Forms.Padding(4);
            this.btnCW.Name = "btnCW";
            this.btnCW.Size = new System.Drawing.Size(149, 56);
            this.btnCW.TabIndex = 47;
            this.btnCW.Text = "CW";
            this.btnCW.UseVisualStyleBackColor = true;
            this.btnCW.Click += new System.EventHandler(this.btnCW_Click);
            // 
            // HallForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1336, 802);
            this.Controls.Add(this.grpSetDir);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.grbSetVel);
            this.Controls.Add(this.gbControl);
            this.Controls.Add(this.gbConnect);
            this.Controls.Add(this.GraphVel);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "HallForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hall BLDC";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HallForm_FormClosing);
            this.Load += new System.EventHandler(this.HallForm_Load);
            this.gbConnect.ResumeLayout(false);
            this.gbControl.ResumeLayout(false);
            this.grbSetVel.ResumeLayout(false);
            this.grbSetVel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpSetDir.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort SerialPort;
        private System.Windows.Forms.Timer TimerPort;
        private System.Windows.Forms.GroupBox gbConnect;
        private System.Windows.Forms.Button btDisconnect;
        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.ComboBox cbSeclectCom;
        private System.Windows.Forms.Timer TimerGraph;
        private System.Windows.Forms.ComboBox cbComName;
        private System.Windows.Forms.GroupBox gbControl;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btScale;
        private System.Windows.Forms.Button btStop;
        private System.Windows.Forms.Button btStart;
        private System.Windows.Forms.GroupBox grbSetVel;
        private System.Windows.Forms.RadioButton rbtVelocity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPWM;
        private System.Windows.Forms.Button btSetPoint;
        private System.Windows.Forms.TextBox txtKpSet;
        private System.Windows.Forms.TextBox txtKdSet;
        private System.Windows.Forms.TextBox txtKiSet;
        private System.Windows.Forms.Button btReSet;
        private System.ComponentModel.BackgroundWorker bkgdWorker;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private ZedGraph.ZedGraphControl GraphVel;
        private System.Windows.Forms.GroupBox grpSetDir;
        private System.Windows.Forms.Button btnCCW;
        private System.Windows.Forms.Button btnCW;
    }
}

