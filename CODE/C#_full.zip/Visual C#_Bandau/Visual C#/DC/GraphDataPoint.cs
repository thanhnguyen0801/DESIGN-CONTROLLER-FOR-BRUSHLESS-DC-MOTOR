﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC
{
    public class GraphDataPoint
    {
        public double Time { get; set; }
        public double Setpoint { get; set; }
        public double Value { get; set; } // Đây có thể là Position hoặc Velocity

        public GraphDataPoint(double time, double setpoint, double value)
        {
            Time = time;
            Setpoint = setpoint;
            Value = value;
        }
    }
}
