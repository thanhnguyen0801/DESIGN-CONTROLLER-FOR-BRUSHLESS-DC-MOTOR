﻿namespace DC
{
    partial class ModeSelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHall = new System.Windows.Forms.Button();
            this.btnEncoder = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(137, 25);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(716, 99);
            this.label5.TabIndex = 59;
            this.label5.Text = "TRƯỜNG ĐẠI HỌC SƯ PHẠM KỸ THUẬT TPHCM\r\nKHOA CƠ KHÍ CHẾ TẠO MÁY\r\nBỘ MÔN: CƠ ĐIỆN T" +
    "Ử\r\n\r\nDỰ ÁN: THIẾT KẾ BỘ ĐIỀU KHIỂN CHO ĐỘNG CƠ BLDC\r\n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::DC.Properties.Resources.FME1;
            this.pictureBox2.Location = new System.Drawing.Point(857, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 145);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DC.Properties.Resources.HCMUTE1;
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 136);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 61;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 159);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(984, 27);
            this.label1.TabIndex = 62;
            this.label1.Text = "CHỌN LOẠI ĐỘNG CƠ BLDC CẦN ĐIỀU KHIỂN\r\n\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnHall
            // 
            this.btnHall.BackColor = System.Drawing.Color.Tan;
            this.btnHall.Font = new System.Drawing.Font("Arial", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHall.Location = new System.Drawing.Point(-3, 211);
            this.btnHall.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHall.Name = "btnHall";
            this.btnHall.Size = new System.Drawing.Size(440, 440);
            this.btnHall.TabIndex = 64;
            this.btnHall.Text = "Hall BLDC";
            this.btnHall.UseVisualStyleBackColor = false;
            this.btnHall.Click += new System.EventHandler(this.btnHall_Click_1);
            // 
            // btnEncoder
            // 
            this.btnEncoder.BackColor = System.Drawing.Color.Silver;
            this.btnEncoder.Font = new System.Drawing.Font("Arial", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEncoder.Location = new System.Drawing.Point(563, 211);
            this.btnEncoder.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnEncoder.Name = "btnEncoder";
            this.btnEncoder.Size = new System.Drawing.Size(440, 440);
            this.btnEncoder.TabIndex = 65;
            this.btnEncoder.Text = "Encoder BLDC";
            this.btnEncoder.UseVisualStyleBackColor = false;
            this.btnEncoder.Click += new System.EventHandler(this.btnEncoder_Click_1);
            // 
            // ModeSelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1002, 652);
            this.Controls.Add(this.btnEncoder);
            this.Controls.Add(this.btnHall);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ModeSelectForm";
            this.Text = "ModeSelectForm";
            this.Load += new System.EventHandler(this.ModeSelectForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHall;
        private System.Windows.Forms.Button btnEncoder;
    }
}