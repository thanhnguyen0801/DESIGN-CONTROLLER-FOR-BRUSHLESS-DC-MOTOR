﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.IO.Ports;
using ZedGraph;
using System.Management;
using System.Drawing.Drawing2D;
using System.Diagnostics;


namespace DC
{
    public partial class EncoderForm : Form

    {
        private int _mode;
        private System.Timers.Timer statusClearTimer;
        private const int StatusDisplayTime = 3000; // 3 giây
        private System.Windows.Forms.Timer _rampTimer;
        private double uq;
        private double ud;
        private List<GraphDataPoint> posDataPoints = new List<GraphDataPoint>();
        private List<GraphDataPoint> velDataPoints = new List<GraphDataPoint>();

        // Vận tốc tối đa của hệ thống 
        private const double MaxVelocity_System = 110.0; // Đơn vị: mm/s

        private double _rampTargetPosition; // Vị trí cuối cùng muốn đạt được
        private double _rampTotalTime;      // Tổng thời gian để đạt được vị trí mục tiêu
        private double _rampCurrentStepCount; // Biến đếm số bước (tick) đã trôi qua
        private double _rampValueToSendEachTick;
        private double _rampStartPosition;
        private int _rampTotalTicks;
        public EncoderForm(int mode)
        {
            _mode = mode; 
            InitializeComponent();
            TimerGraph = new System.Windows.Forms.Timer();
            TimerGraph.Interval = 100;
            TimerGraph.Tick += TimerGraph_Tick;
            TimerGraph.Start();
            
            _rampTimer = new System.Windows.Forms.Timer();
            _rampTimer.Tick += _rampTimer_Tick; // Gán sự kiện Tick cho rampTimer
            _rampTimer.Interval = 100; // Đặt khoảng thời gian cho timer (ví dụ 100ms)
            SetupZedGraph();
        }

        private void _rampTimer_Tick(object sender, EventArgs e)
        {
            _rampCurrentStepCount++;
            double currentValueToSend;
            bool rampFinished = (_rampCurrentStepCount >= _rampTotalTicks);
            if (!rampFinished)
            {
                currentValueToSend = _rampStartPosition + (_rampCurrentStepCount * _rampValueToSendEachTick);
            }
            else
            {
                currentValueToSend = _rampTargetPosition;
                _rampTimer.Stop();
                DisplayStatusMessage("Ramp đã hoàn thành!");
            }
            try
            {
                if (SerialPort.IsOpen)
                {
                    set_pos = currentValueToSend;
                    SerialPort.Write(currentValueToSend.ToString("F2", CultureInfo.InvariantCulture) + "t");
                }
                else
                {
                    DisplayStatusMessage("Serial Port chưa mở. Không thể gửi dữ liệu ramp.");
                    _rampTimer.Stop();
                }
            }
            catch (Exception ex)
            {
                DisplayStatusMessage($"Lỗi khi gửi dữ liệu ramp: {ex.Message}");
                _rampTimer.Stop();
            }
        }

        private void SetupZedGraph()
        {
            GraphPane posPane = GraphPos.GraphPane;
            posPane.CurveList.Clear(); 
            posPane.Title.Text = "Position Graph"; 
            posPane.XAxis.Title.Text = "Time (s)";
            posPane.YAxis.Title.Text = "Position (mm)"; 
            // Cài đặt chung cho trục
            posPane.Title.FontSpec.Size = 20;
            posPane.XAxis.Title.FontSpec.Size = 20;
            posPane.YAxis.Title.FontSpec.Size = 20;
            posPane.Legend.FontSpec.Size = 20; 
            posPane.Legend.FontSpec.IsBold = true;
            posPane.XAxis.MajorGrid.IsVisible = true;
            posPane.YAxis.MajorGrid.IsVisible = true;
            // Màu nền: trắng - xanh dương nhạt
            posPane.Chart.Fill = new Fill(Color.White, Color.FromArgb(173, 216, 230), 45.0f); 
            posPane.Fill = new Fill(Color.White, Color.White, 45.0f);
            // Khởi tạo các danh sách điểm sử dụng RollingPointPairList
            IPointListEdit list1 = new RollingPointPairList(1000);
            IPointListEdit list2 = new RollingPointPairList(1000);
            // Thêm các đường cong vào GraphPane
            posPane.AddCurve("Set Point", list1, Color.Red, SymbolType.None); 
            posPane.AddCurve("Position", list2, Color.Blue, SymbolType.None); 
            // Cài đặt các trục khác (ví dụ: autoscale, min/max ban đầu)
            posPane.XAxis.Scale.Min = 0;
            posPane.XAxis.Scale.Max = 30; 
            posPane.XAxis.Scale.MajorStep = 5;
            posPane.YAxis.Scale.Min = 0; 
            posPane.YAxis.Scale.Max = 350; 
            posPane.YAxis.Scale.IsVisible = true;
            GraphPos.AxisChange();
            // ***** GRAPH VELOCITY *****
            GraphPane velPane = GraphVel.GraphPane;
            velPane.CurveList.Clear(); 
            velPane.Title.Text = "Velocity Graph"; 
            velPane.XAxis.Title.Text = "Time (s)";
            velPane.YAxis.Title.Text = "Velocity (rad/s)"; 
            // Cài đặt chung cho trục
            velPane.Title.FontSpec.Size = 20;
            velPane.XAxis.Title.FontSpec.Size = 20;
            velPane.YAxis.Title.FontSpec.Size = 20;
            velPane.XAxis.MajorGrid.IsVisible = true;
            velPane.YAxis.MajorGrid.IsVisible = true;
            velPane.Legend.FontSpec.Size = 20; 
            velPane.Legend.FontSpec.IsBold = true;
            // Màu nền: trắng - cam nhạt
            velPane.Chart.Fill = new Fill(Color.White, Color.FromArgb(255, 236, 179), 45.0f); 
            velPane.Fill = new Fill(Color.White, Color.White, 45.0f);
            // Khởi tạo các danh sách điểm sử dụng RollingPointPairList
            IPointListEdit list3 = new RollingPointPairList(1000); 
            IPointListEdit list4 = new RollingPointPairList(1000); 
            // Thêm các đường cong vào GraphPane
            velPane.AddCurve("Set Point", list3, Color.Red, SymbolType.None);
            velPane.AddCurve("Velocity", list4, Color.Blue, SymbolType.None); 
            // Cài đặt các trục khác
            velPane.XAxis.Scale.Min = 0;
            velPane.XAxis.Scale.Max = 30; 
            velPane.XAxis.Scale.MajorStep = 5;
            velPane.YAxis.Scale.Min = -80; 
            velPane.YAxis.Scale.Max = 80; 
            velPane.YAxis.Scale.IsVisible = true;
            GraphVel.AxisChange();
        }
        private void EncoderForm_Load(object sender, EventArgs e)
        {
            SerialPort_Initialize();
            check = true;
            rbtVelocity.Checked = true;
            txtPosition.Enabled = false;
            txtVelocity.Enabled = true;
            TimerGraph.Enabled = false;
            TimerGraph.Interval = 100;
            TimerGraph.Stop(); 
            //setup timerport
            TimerPort.Enabled = true;
            TimerPort.Tick += new EventHandler(TimerPort_Tick);
            TimerPort.Interval = 100;
            TimerPort.Start();
            // Thêm phần khởi tạo timer
            statusClearTimer = new System.Timers.Timer(StatusDisplayTime);
            statusClearTimer.Elapsed += ClearStatusBox;
            statusClearTimer.AutoReset = false; 
            SerialPort.DataReceived += SerialPort_DataReceived;
            if (string.IsNullOrEmpty(txtPosition.Text))
            {
                txtPosition.Text = "0.00"; 
            }
            if (string.IsNullOrEmpty(txtVelocity.Text))
            {
                txtVelocity.Text = "0.00"; 
            }
            // 2. Cập nhật giá trị ban đầu cho các biến set_pos và set_vel từ textbox
            double.TryParse(txtPosition.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out set_pos);
            double.TryParse(txtVelocity.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out set_vel);
        }

        private string _serialBuffer = "";
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                _serialBuffer += SerialPort.ReadExisting();
                string newlineSequence = SerialPort.NewLine; // Lấy "\r\n"

                while (_serialBuffer.Contains(newlineSequence))
                {
                    int newlineIndex = _serialBuffer.IndexOf(newlineSequence);
                    string completeData = _serialBuffer.Substring(0, newlineIndex);
                    _serialBuffer = _serialBuffer.Substring(newlineIndex + newlineSequence.Length);
                    this.BeginInvoke((MethodInvoker)delegate
                    {
                        ProcessSerialData(completeData); // completeData đã sạch '\r\n'
                    });
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Serial Error: {ex.Message}");
            }
        }
      
        // Hàm nhận dữ liệu và vẽ đồ thị
        private void ProcessSerialData(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                Debug.WriteLine("ProcessSerialData received empty or null data.");
                return;
            }
            data = data.Trim(); 
            Debug.WriteLine($"[ProcessSerialData] Processed data: '{data}'"); 
            if (data.Length > 0)
            {
                char dataType = data[0]; 
                string content = data.Substring(1); 
                this.Invoke((MethodInvoker)delegate
                {
                    switch (dataType)
                    {
                        case 'V':
                            if (double.TryParse(content, NumberStyles.Any, CultureInfo.InvariantCulture, out double velValue))
                            {
                                vel = velValue;
                                txtVel.Text = velValue.ToString("0.00");
                            }
                            else
                            {
                                Debug.WriteLine($"[ProcessSerialData] Error parsing Velocity value: '{content}'. Full data: '{data}'");
                                DisplayStatusMessage(data); // Hiển thị lỗi nếu 'V' nhưng không phải số
                            }
                            break;
                        case 'P':
                            if (double.TryParse(content, NumberStyles.Any, CultureInfo.InvariantCulture, out double posValue))
                            {
                                pos = posValue;
                                txtPos.Text = posValue.ToString("0.00");
                            }
                            else
                            {
                                Debug.WriteLine($"[ProcessSerialData] Error parsing Position value: '{content}'. Full data: '{data}'");
                                DisplayStatusMessage(data); // Hiển thị lỗi nếu 'P' nhưng không phải s
                            }
                            break;
                        case 'Q':
                            if (double.TryParse(content, NumberStyles.Any, CultureInfo.InvariantCulture, out double uqValue))
                            {
                                uq = uqValue;
                                txtUq.Text = uqValue.ToString("0.00");
                            }
                            else
                            {
                                Debug.WriteLine($"[ProcessSerialData] Error parsing Uq value: '{content}'. Full data: '{data}'");
                                DisplayStatusMessage(data); // Hiển thị lỗi nếu 'Q' nhưng không phải số
                            }
                            break;
                        case 'D':
                            if (double.TryParse(content, NumberStyles.Any, CultureInfo.InvariantCulture, out double udValue))
                            {
                                ud = udValue;
                                txtUd.Text = udValue.ToString("0.00");
                            }
                            else
                            {
                                Debug.WriteLine($"[ProcessSerialData] Error parsing Ud value: '{content}'. Full data: '{data}'");
                                DisplayStatusMessage(data); // Hiển thị lỗi nếu 'D' nhưng không phải số
                            }
                            break;

                        case 'C': // TRẠNG THÁI "CONNECTED/DONE"
                            CalibFail.Visible = false;
                            CalibFirst.Visible = false;
                            CalibDone.Visible = true;
                            break;

                        case 'F': // TRẠNG THÁI "FAULT/FAIL"
                            CalibDone.Visible = false;
                            CalibFirst.Visible = false;
                            CalibFail.Visible = true;
                            break;    
                            
                        case 'M':
                            DisplayStatusMessage(content); // Chỉ hiển thị nội dung sau 'M'
                            break;
                        default:



                            Debug.WriteLine($"[ProcessSerialData] Unrecognized data format or type. Displaying as general message: '{data}'");

                            DisplayStatusMessage(data); // Hiển thị toàn bộ chuỗi nhận được vào statusBox

                            break;

                    }

                });

            }

            else 
            {

                Debug.WriteLine("ProcessSerialData received empty string after trim.");
            }

        }
        public void DisplayStatusMessage(string message)
        {
            if (statusBox.InvokeRequired)
            {
                statusBox.Invoke(new Action<string>(DisplayStatusMessage), message);
                return;
            }
            statusBox.AppendText(message + Environment.NewLine);
            string[] currentLines = statusBox.Lines;
            if (currentLines.Length > 30)
            {
                string[] newLines = currentLines.Skip(currentLines.Length - 30).ToArray();
                statusBox.Text = string.Join(Environment.NewLine, newLines);
                statusBox.SelectionStart = statusBox.Text.Length;
                statusBox.ScrollToCaret();
            }
            else
            {
                statusBox.SelectionStart = statusBox.Text.Length;
                statusBox.ScrollToCaret();
            }
        }
        private void ClearStatusBox(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (statusBox.InvokeRequired)
            {
                statusBox.Invoke(new Action(() => statusBox.Text = ""));
                return;
            }
            statusBox.Text = "";
        }
        private void SerialPort_Initialize()
        {
            //Baud Rate
            cbBaudRate.Items.Add(19200);
            cbBaudRate.Items.Add(38400);
            cbBaudRate.Items.Add(57600);
            cbBaudRate.Items.Add(115200);
            cbBaudRate.Items.Add(128000);
            cbBaudRate.Items.Add(256000);
            cbBaudRate.Items.ToString();
            //get first item print in text
            cbBaudRate.Text = cbBaudRate.Items[3].ToString();
        }
        int SumPort = 0;
        private void TimerPort_Tick(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            if (SumPort != ports.Length)
            {
                SumPort = ports.Length;
                cbSeclectCom.Items.Clear();
                foreach (COMPortInfo PortCOMs in COMPortInfo.GetCOMPortsInfo())
                {
                    cbSeclectCom.Items.Add(string.Format("{0} – {1}", PortCOMs.Name, PortCOMs.Description));
                    cbComName.Items.Add(PortCOMs.Name);
                }
                cbSeclectCom.SelectedIndex = 0;
                cbComName.SelectedIndex = 0;
            }
        }

        /* -------------------------------- Vẽ đồ thị---------------------------------- */

        int tickStart = 0;

        double pos, vel, set_pos, set_vel, mv;

        bool scroll = true, check = true;



        public void ZedGraph_Draw()

        {

            if (GraphPos.GraphPane.CurveList.Count < 2)

            {

                Debug.WriteLine("ZedGraph_Draw: Not enough curves for Position Graph.");

                return;

            }

            if (GraphVel.GraphPane.CurveList.Count < 2)

            {

                Debug.WriteLine("ZedGraph_Draw: Not enough curves for Velocity Graph.");

                return;

            }

            LineItem curve1 = GraphPos.GraphPane.CurveList[0] as LineItem; // Set Point Pos

            LineItem curve2 = GraphPos.GraphPane.CurveList[1] as LineItem; // Position



            LineItem curve3 = GraphVel.GraphPane.CurveList[0] as LineItem; // Set Point Vel

            LineItem curve4 = GraphVel.GraphPane.CurveList[1] as LineItem; // Velocity



            if (curve1 == null || curve2 == null || curve3 == null || curve4 == null)

            {

                Debug.WriteLine("ZedGraph_Draw: One or more curves not found or not of type LineItem.");

                return;

            }

            IPointListEdit list1 = curve1.Points as IPointListEdit;

            IPointListEdit list2 = curve2.Points as IPointListEdit;

            IPointListEdit list3 = curve3.Points as IPointListEdit;

            IPointListEdit list4 = curve4.Points as IPointListEdit;



            if (list1 == null || list2 == null || list3 == null || list4 == null)

            {

                Debug.WriteLine("ZedGraph_Draw: One or more point lists not found.");

                return;

            }

            double time = (Environment.TickCount - tickStart) / 1000.0;



            // Thêm điểm vào các danh sách. RollingPointPairList sẽ tự động loại bỏ điểm cũ.

            list1.Add(time, set_pos); // set_pos là giá trị bạn đặt từ textbox vị trí

            list2.Add(time, pos);     // pos là giá trị thực tế đọc từ serial



            list3.Add(time, set_vel); // set_vel là giá trị bạn đặt từ textbox vận tốc

            list4.Add(time, vel);     // vel là giá trị thực tế đọc từ serial
            posDataPoints.Add(new GraphDataPoint(time, set_pos, pos));
            velDataPoints.Add(new GraphDataPoint(time, set_vel, vel));

            const int maxDataPointsToStore = 10000; // Giới hạn 10,000 điểm
            if (posDataPoints.Count > maxDataPointsToStore)
            {
                posDataPoints.RemoveRange(0, posDataPoints.Count - maxDataPointsToStore);
            }
            if (velDataPoints.Count > maxDataPointsToStore)
            {
                velDataPoints.RemoveRange(0, velDataPoints.Count - maxDataPointsToStore);
            }
            // -------------------------------------------------------------------


            // Xử lý trục X tự động cuộn

            Scale PosScale = GraphPos.GraphPane.XAxis.Scale;

            if (scroll) // Chỉ cuộn nếu scroll là true

            {

                PosScale.Max = time + PosScale.MajorStep;

                PosScale.Min = PosScale.Max - 30.0; // Giữ cửa sổ 30 giây

            }

            else // Nếu không cuộn, trục X tự động mở rộng

            {

                PosScale.Min = 0; // Giữ nguyên điểm bắt đầu

                PosScale.Max = Math.Max(PosScale.Max, time + PosScale.MajorStep); // Chỉ mở rộng Max

            }
            Scale VelScale = GraphVel.GraphPane.XAxis.Scale;

            if (scroll) // Chỉ cuộn nếu scroll là true

            {

                VelScale.Max = time + VelScale.MajorStep;

                VelScale.Min = VelScale.Max - 30.0; // Giữ cửa sổ 30 giây

            }

            else // Nếu không cuộn

            {

                VelScale.Min = 0;

                VelScale.Max = Math.Max(VelScale.Max, time + VelScale.MajorStep);

            }


            GraphPos.AxisChange();

            GraphPos.Invalidate();

            GraphVel.AxisChange();

            GraphVel.Invalidate();

        }



        private void btConnect_Click(object sender, EventArgs e)

        {

            try

            {

                if (SerialPort.IsOpen) SerialPort.Close();



                SerialPort.PortName = cbComName.Text;

                SerialPort.BaudRate = Convert.ToInt32(cbBaudRate.Text);

                SerialPort.DataBits = 8;

                SerialPort.StopBits = StopBits.One;

                SerialPort.Parity = Parity.None;

                SerialPort.Handshake = Handshake.None;

                SerialPort.ReadTimeout = 500;

                SerialPort.WriteTimeout = 500;

                SerialPort.NewLine = "\r\n"; // Phù hợp với STM32



                SerialPort.Open();
                gbConnect.Text = "Connected: " + cbSeclectCom.Text;
                tickStart = Environment.TickCount;
                TimerGraph.Enabled = true; // Bắt đầu timer vẽ đồ thị khi kết nối thành công
            }

            catch (Exception ex)

            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btExit_Click(object sender, EventArgs e)

        {
            DialogResult msg;

            msg = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (msg == DialogResult.Yes)

            {
                TimerGraph.Stop();
                SerialPort.Close();
                Application.Exit();
            }
        }

        private void btScale_Click(object sender, EventArgs e)

        {
            this.Close();
        }



        private void btStart_Click(object sender, EventArgs e)

        {

            try

            {

                SerialPort.Write("r");

                TimerGraph.Start();

            }

            catch (Exception ex)

            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }



        }

        private void bkgdWorker_DoWork(object sender, DoWorkEventArgs e)

        {



        }
        delegate void SetTextCallback(string text);
        private void rbtPosition_CheckedChanged(object sender, EventArgs e)

        {

            if (rbtPosition.Checked) 

            {

                check = false;

                txtPosition.Enabled = true;

                txtVelocity.Enabled = false; 

            }

        }
        private void rbtVelocity_CheckedChanged(object sender, EventArgs e)

        {

            if (rbtVelocity.Checked) 

            {

                check = true;

                txtPosition.Enabled = false;

                txtVelocity.Enabled = true; 

            }

        }
        private void btSetPoint_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtPosition.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double parsedPos))
            {
                set_pos = parsedPos;
            }
            else
            {
                set_pos = 0; 
                Debug.WriteLine($"Error: Could not parse Position value '{txtPosition.Text}'. Defaulting to 0.");
                MessageBox.Show("Invalid Position value. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }

            if (double.TryParse(txtVelocity.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double parsedVel))
            {
                set_vel = parsedVel;
            }
            else
            {
                set_vel = 0; 
                Debug.WriteLine($"Error: Could not parse Velocity value '{txtVelocity.Text}'. Defaulting to 0.");
                MessageBox.Show("Invalid Velocity value. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }


            try
            {

                if (!SerialPort.IsOpen)
                {
                    MessageBox.Show("Serial Port is not open. Please connect first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }


                if (!check) 
                {
                    SerialPort.Write("a");
                    SerialPort.Write(parsedPos.ToString("F2", CultureInfo.InvariantCulture) + "s");
                }
                else 
                {

                    SerialPort.Write("b");

                    SerialPort.Write(parsedVel.ToString("F2", CultureInfo.InvariantCulture) + "v");
                }


                TimerGraph.Start();
            }
            catch (Exception ex)
            {
 
                MessageBox.Show($"Error sending data: {ex.Message}", "Serial Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btReSet_Click(object sender, EventArgs e)

        {
            GraphPos.GraphPane.CurveList.Clear();

            GraphVel.GraphPane.CurveList.Clear();

            GraphPos.GraphPane.GraphObjList.Clear();

            GraphVel.GraphPane.GraphObjList.Clear();

            // --- VỊ TRÍ CẦN THÊM CODE: BỔ SUNG HAI DÒNG NÀY VÀO ĐÂY ---
            posDataPoints.Clear();
            velDataPoints.Clear();
            // ----------------------------------------------------------
            SetupZedGraph(); 
            TimerGraph.Enabled = false; 
        }

        private void grbSetVel_Enter(object sender, EventArgs e)

        {



        }

        private void txtPos_TextChanged(object sender, EventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {
        }





        private void GraphVel_Load(object sender, EventArgs e)

        {



        }



        private void GraphPos_Load(object sender, EventArgs e)

        {



        }



        private void label5_Click(object sender, EventArgs e)

        {



        }
        private void label10_Click(object sender, EventArgs e)

        {



        }

        private void statusBox_TextChanged(object sender, EventArgs e)

        {

            statusBox.Font = new Font(

              familyName: "Consolas", // Tên font (Arial, Times New Roman, etc.)

                      emSize: 9.0f,           // Kích thước chữ (float)

                      style: FontStyle.Regular // Kiểu chữ (Regular, Bold, Italic...)

                  );

            statusBox.Multiline = true;

            statusBox.ScrollBars = ScrollBars.Vertical;

        }



        private bool _isPaused = false;

        private void btPause_Click(object sender, EventArgs e)

        {

            try

            {

                if (btPause.Text == "Pause")

                {

                    btPause.Text = "Resume";

                    SerialPort.Write("f");//tam dung

                    _isPaused = true; // Bật cờ tạm dừng

                    TimerGraph.Stop(); // Dừng cập nhật đồ thị khi tạm dừng

                }

                else

                {

                    btPause.Text = "Pause";

                    SerialPort.Write("g");// tiep tuc

                    _isPaused = false; // Tắt cờ tạm dừng

                    TimerGraph.Start(); // Tiếp tục cập nhật đồ thị khi resume

                }

            }

            catch (Exception ex)

            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        private void txtVelocity_TextChanged(object sender, EventArgs e)

        {



        }



        private void txtUd_TextChanged(object sender, EventArgs e)

        {



        }



        private void CalibFail_Click(object sender, EventArgs e)

        {



        }

        // Hàm này sẽ được gọi khi bạn click nút "Show Position Data"
        private void btnShowPosData_Click(object sender, EventArgs e)
        {
            // Tạo một instance mới của DataTableForm
            DataTableForm dataForm = new DataTableForm();
            // Truyền dữ liệu vị trí và tên cột tương ứng
            dataForm.LoadData(posDataPoints, "Position (mm)");
            // Đặt tiêu đề cho cửa sổ bảng dữ liệu
            dataForm.Text = "Position Data Table";
            // Hiển thị cửa sổ
            dataForm.Show();
        }

        // Hàm này sẽ được gọi khi bạn click nút "Show Velocity Data"
        private void btnShowVelData_Click(object sender, EventArgs e)
        {
            // Tạo một instance mới của DataTableForm
            DataTableForm dataForm = new DataTableForm();
            // Truyền dữ liệu vận tốc và tên cột tương ứng
            dataForm.LoadData(velDataPoints, "Velocity (rad/s)");
            // Đặt tiêu đề cho cửa sổ bảng dữ liệu
            dataForm.Text = "Velocity Data Table";
            // Hiển thị cửa sổ
            dataForm.Show();
        }

        private void txtPosRamp_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtTimeRamp_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSetRamp_Click(object sender, EventArgs e)
        {
            // 1. Dừng rampTimer cũ nếu đang chạy
            _rampTimer.Stop();

            // 2. Đọc giá trị từ các textbox
            bool parsePosOk = double.TryParse(txtPosRamp.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _rampTargetPosition);
            bool parseTimeOk = double.TryParse(txtTimeRamp.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _rampTotalTime);

            if (!parsePosOk || !parseTimeOk || _rampTotalTime <= 0)
            {
                MessageBox.Show("Vui lòng nhập giá trị Pos và Time hợp lệ cho Ramp. Time phải lớn hơn 0.", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Dừng lại nếu nhập liệu không hợp lệ
            }

            _rampStartPosition = pos;

            // --- KIỂM TRA VẬN TỐC (Logic đã thêm trước đó) ---
            double totalChangeForVelocity = _rampTargetPosition - _rampStartPosition; // Tính tổng thay đổi để kiểm tra vận tốc
            double calculatedRampVelocity = Math.Abs(totalChangeForVelocity) / _rampTotalTime; // Vận tốc trung bình

            if (calculatedRampVelocity > MaxVelocity_System)
            {
                MessageBox.Show($"Vận tốc mong muốn của Ramp ({calculatedRampVelocity:F2} mm/s) vượt quá vận tốc tối đa cho phép của hệ thống ({MaxVelocity_System:F2} mm/s).\n\nVui lòng giảm Pos hoặc tăng Time.", "Lỗi Vận Tốc Ramp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Dừng lại, không bắt đầu Ramp
            }
            // 3. Khởi tạo lại biến đếm bước
            _rampCurrentStepCount = 0;

            // Tính toán tổng số tick và lưu vào biến mới _rampTotalTicks
            int numberOfTicks = (int)(_rampTotalTime * 1000 / _rampTimer.Interval);
            if (numberOfTicks == 0) // Xử lý trường hợp thời gian ramp quá ngắn so với interval
            {
                _rampTotalTicks = 1;
                _rampValueToSendEachTick = (_rampTargetPosition - _rampStartPosition);
            }
            else
            {
                _rampTotalTicks = numberOfTicks; // LƯU TỔNG SỐ TICK VÀO BIẾN MỚI
                _rampValueToSendEachTick = (_rampTargetPosition - _rampStartPosition) / _rampTotalTicks;
            }

            DisplayStatusMessage($"Bắt đầu Ramp: Từ {_rampStartPosition:F2} đến {_rampTargetPosition:F2}, Thời gian = {_rampTotalTime:F2}s, Vận tốc = {calculatedRampVelocity:F2} mm/s, Giá trị mỗi bước = {_rampValueToSendEachTick:F4}");

            _rampTimer.Start();
        }

        private void btnResetRamp_Click(object sender, EventArgs e)
        {
            // 1. Dừng Ramp Timer
            _rampTimer.Stop();
            DisplayStatusMessage("Ramp đã được Reset.");

            // 2. Đặt lại các biến liên quan đến Ramp về trạng thái ban đầu
            _rampCurrentStepCount = 0;
            _rampTargetPosition = 0;
            _rampTotalTime = 0;
            _rampValueToSendEachTick = 0;

            // 3. (Tùy chọn) Đặt lại Set Point của đồ thị về 0 và gửi lệnh dừng động cơ
            // Việc này tùy thuộc vào cách bạn muốn động cơ phản ứng khi Reset Ramp.
            // Nếu muốn động cơ dừng lại ngay lập tức tại vị trí hiện tại của nó, bạn có thể không cần gửi lệnh gì.
            // Nếu muốn nó về 0, bạn có thể gửi lệnh "a0.00s"
            try
            {
                if (SerialPort.IsOpen)
                {
                    // Gửi lệnh để đặt vị trí mục tiêu về 0, nếu bạn muốn động cơ trở về 0 sau khi reset ramp
                    // Hoặc bạn có thể gửi lệnh dừng tùy theo cách điều khiển của bạn.
                    SerialPort.Write("a");
                    SerialPort.Write("0.00s"); // Gửi về vị trí 0
                    set_pos = 0; // Cập nhật set_pos để đồ thị Set Point cũng về 0
                }
            }
            catch (Exception ex)
            {
                DisplayStatusMessage($"Lỗi khi gửi lệnh dừng động cơ sau Reset Ramp: {ex.Message}");
            }

            // 4. (Tùy chọn) Xóa dữ liệu cũ trên đồ thị và reset lại đồ thị
            // Tương tự như nút btReSet_Click
            GraphPos.GraphPane.CurveList.Clear();
            GraphVel.GraphPane.CurveList.Clear();
            GraphPos.GraphPane.GraphObjList.Clear();
            GraphVel.GraphPane.GraphObjList.Clear();
            posDataPoints.Clear();
            velDataPoints.Clear();
            SetupZedGraph(); // Gọi lại hàm setup để khởi tạo các đường cong mới
            TimerGraph.Enabled = false; // Dừng TimerGraph nếu bạn muốn đồ thị dừng cập nhật
        }

        private void txtPosition_TextChanged(object sender, EventArgs e)
        {

        }

        double errPos = 0;

        private void TimerGraph_Tick(object sender, EventArgs e)

        {

            // _isPaused đã được xử lý trong btPause_Click

            // if (!_isPaused) // Chỉ vẽ đồ thị khi không ở trạng thái tạm dừng

            // {

            ZedGraph_Draw();

            // }



            // Cập nhật Error (nếu có)

            errPos = set_pos - pos;



        }



        private void cbSeclectCom_SelectedIndexChanged(object sender, EventArgs e)

        {

            cbComName.SelectedIndex = cbSeclectCom.SelectedIndex;

        }
        private void btDisconnect_Click(object sender, EventArgs e)

        {

            gbConnect.Text = "Disconnect";

            TimerGraph.Stop();              //Stop timer(s), whatever it takes

            TimerPort.Enabled = true;       // Start timer to scan port



            bkgdWorker.CancelAsync();

            System.Threading.Thread.Sleep(500); //Wait bkworker to finish

            SerialPort.Close();

        }

        private void EncoderForm_FormClosing(object sender, FormClosingEventArgs e)

        {

            DialogResult msg;

            msg = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (msg == DialogResult.Yes)

            {

                SerialPort.Close();

                TimerGraph.Stop();

                e.Cancel = false;

            }

            else e.Cancel = true;

        }

    }

}