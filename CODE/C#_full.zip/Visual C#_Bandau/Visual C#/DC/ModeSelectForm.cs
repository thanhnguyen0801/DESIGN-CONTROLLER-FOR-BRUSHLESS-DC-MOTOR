﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DC
{
    public partial class ModeSelectForm : Form
    {
        public int SelectedMode { get; private set; } = 0;
        public ModeSelectForm()
        {
            InitializeComponent();
        }

        private void ModeSelectForm_Load(object sender, EventArgs e)
        {

        }




        private void btnHall_Click_1(object sender, EventArgs e)
        {
            this.Hide(); // Ẩn form chọn mode
            var hallForm = new HallForm(1);
            hallForm.FormClosed += (s, args) => this.Show(); // Khi HallForm đóng lại, hiện lại ModeSelectForm
            hallForm.Show();
        }

        private void btnEncoder_Click_1(object sender, EventArgs e)
        {
            this.Hide(); // Ẩn form chọn mode
            var encoderForm = new EncoderForm(2);
            encoderForm.FormClosed += (s, args) => this.Show(); // Khi EncoderForm đóng lại, hiện lại ModeSelectForm
            encoderForm.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}