﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DC // Đảm bảo namespace này khớp với namespace của project bạn
{
    public partial class DataTableForm : Form
    {
        private DataGridView dgvData; // Khai báo DataGridView

        public DataTableForm()
        {
            InitializeComponent();
            SetupDataGridView(); // Gọi hàm cài đặt DataGridView
        }

        private void SetupDataGridView()
        {
            dgvData = new DataGridView(); // Khởi tạo DataGridView
            dgvData.Dock = DockStyle.Fill; // Đặt nó lấp đầy Form
            dgvData.ReadOnly = true; // Chỉ cho phép đọc
            dgvData.AllowUserToAddRows = false; // Không cho phép người dùng thêm dòng mới
            dgvData.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Tự động co giãn cột
            this.Controls.Add(dgvData); // Thêm DataGridView vào Form
        }

        // Hàm này dùng để truyền dữ liệu từ Form chính sang DataTableForm
        public void LoadData(List<GraphDataPoint> dataPoints, string valueColumnName)
        {
            // Xóa các cột cũ nếu có (đảm bảo không bị trùng lặp khi Load lại)
            dgvData.Columns.Clear();

            // Thêm các cột cho bảng
            dgvData.Columns.Add("Time", "Time (s)");
            dgvData.Columns.Add("Setpoint", "Set Point");
            dgvData.Columns.Add("Value", valueColumnName); // Tên cột sẽ là "Position (mm)" hoặc "Velocity (rad/s)"

            // Thêm dữ liệu từ List vào DataGridView
            foreach (var point in dataPoints)
            {
                // "F3" định dạng số thập phân với 3 chữ số sau dấu phẩy
                dgvData.Rows.Add(point.Time.ToString("F3"), point.Setpoint.ToString("F3"), point.Value.ToString("F3"));
            }
        }
    }
}